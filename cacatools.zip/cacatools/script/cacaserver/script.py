import os
import sys
import subprocess

# Fungsi untuk membaca file dan mencari domain yang cocok
def find_matching_domain(file_path, input_subdomain):
    """
    Membaca file datatoken.txt dan mencari domain yang cocok dengan subdomain input.
    """
    matched_domain = ""
    matched_data = ""

    with open(file_path, "r") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) == 3:
                domain = parts[0]
                if domain in input_subdomain:
                    if not matched_domain or len(domain) > len(matched_domain):
                        matched_domain = domain
                        matched_data = line.strip()

    return matched_data

# Fungsi untuk menjalankan perintah curl
def api_request(domain, username, token, record_name, txtdata):
    """
    Menambahkan DNS TXT record melalui perintah curl menggunakan cPanel API.
    """
    curl_command = f"""
    curl -s -X GET "https://{domain}:2083/json-api/cpanel" \
      -H "Authorization: cpanel {username}:{token}" \
      -d "cpanel_jsonapi_user={username}&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=ZoneEdit&cpanel_jsonapi_func=add_zone_record&domain={domain}&name={record_name}&type=TXT&txtdata={txtdata}"
    """
    print(f"[INFO] Menjalankan perintah curl:\n{curl_command}")
    result = subprocess.run(curl_command, shell=True, capture_output=True, text=True)
    print(f"[INFO] Hasil curl:\n{result.stdout}")
    return result.stdout

# Fungsi untuk validasi dengan nslookup
def run_nslookup(record_name):
    """
    Mengecek propagasi DNS record menggunakan nslookup.
    """
    try:
        result = subprocess.check_output(['nslookup', '-query=TXT', record_name], stderr=subprocess.STDOUT)
        return result.decode()
    except subprocess.CalledProcessError as e:
        return f"[ERROR] nslookup gagal: {e.output.decode()}"

# Fungsi utama
def main():
    if len(sys.argv) != 4:
        print("Usage: script.py <subdomain> <record_name> <record_value>")
        sys.exit(1)

    input_subdomain = sys.argv[1]
    full_record_name = sys.argv[2]
    record_value = sys.argv[3]

    print(f"[INFO] Proses dimulai untuk subdomain: {input_subdomain}")
    print(f"[INFO] Record name: {full_record_name}, token validasi: {record_value}")

    # Path ke file datatoken.txt
    file_path = "datatoken/datatoken.txt"
    if not os.path.exists(file_path):
        print(f"[ERROR] File {file_path} tidak ditemukan.")
        sys.exit(1)

    # Cari domain yang cocok
    matched_data = find_matching_domain(file_path, input_subdomain)
    if not matched_data:
        print("[ERROR] Domain tidak ditemukan dalam datatoken.txt.")
        sys.exit(1)

    domain, username, token = matched_data.split()
    print(f"[INFO] Domain ditemukan: {domain}")
    print(f"[INFO] Username: {username}, Token API: {token}")

    # Ekstraksi nama record
    record_name = full_record_name.replace(f".{domain}", "")
    print(f"[INFO] Nama record yang dimodifikasi: {record_name}")

    # Menambahkan DNS record
    response = api_request(domain, username, token, record_name, record_value)

    # Validasi hasil dengan nslookup
    print("[INFO] Menunggu 5 detik untuk propagasi DNS...")
    subprocess.run(["sleep", "10"])
    print(f"[INFO] Mengecek record TXT dengan nslookup: {full_record_name}")
    nslookup_result = run_nslookup(full_record_name)
    print("[DEBUG] Hasil nslookup:\n", nslookup_result)

    # Konfirmasi apakah record TXT berhasil ditambahkan
    if record_value in nslookup_result:
        print("[INFO] Record TXT berhasil ditambahkan dan valid.")
        sys.exit(0)
    else:
        print("[ERROR] Record TXT belum tersedia atau tidak cocok.")
        sys.exit(1)

if __name__ == "__main__":
    main()

