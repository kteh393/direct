#!/bin/bash

# ========================================
#     Skrip Otomasi Setup Domain & SSL
# ========================================
# Adjust the variables below as necessary.

ROOT_FOLDER="/var/www/html"
PHP_VERSION="8.1"
CLOUDFLARE_ENABLED=false
API_TOKEN=""  # Cloudflare API token if CLOUDFLARE_ENABLED is true
EMAIL="admin@example.com"
DOMAINS_FILE="/root/cacatools/output/domains.txt"
AUTH_HOOK="/root/cacatools/script/cacaserver/auth-hook.sh"
LOG_FILE="/root/cacatools/script/cacaserver/logs/domain_setup.log"
CRON_FILE="/etc/cron.d/ssl_renew"
SERVER_IP=$(curl -s ifconfig.me)

# Create log directory if it doesn't exist
mkdir -p "$(dirname "$LOG_FILE")"
exec > >(tee -i "$LOG_FILE") 2>&1

# Function: Display Banner
display_banner() {
    if ! command -v figlet &>/dev/null; then
        echo "[INFO] Installing figlet for banner display..."
        apt-get update -y && apt-get install -y figlet
    fi
    figlet -c -f standard "SETUP SERVER"
    figlet -c -f slant "BY"
    figlet -c -f slant "CACA-CAYA"
}

# Function: Check Ubuntu Version
check_ubuntu_version() {
    echo "[INFO] Checking Ubuntu version..."
    UBUNTU_VERSION=$(lsb_release -rs 2>/dev/null)
    SUPPORTED_VERSIONS=("18.04" "18.10" "20.04" "20.10" "22.04" "22.10")
    if [[ ! " ${SUPPORTED_VERSIONS[@]} " =~ " ${UBUNTU_VERSION} " ]]; then
        echo "[ERROR] Ubuntu version $UBUNTU_VERSION is not supported (supports only 18.x, 20.x, 22.x)."
        exit 1
    fi
    echo "[INFO] Ubuntu version $UBUNTU_VERSION is supported."
}

# Function: Install Dependencies
install_dependencies() {
    echo "[INFO] Updating system & installing required packages..."
    apt-get update -y && apt-get upgrade -y
    apt-get install -y apache2 php${PHP_VERSION} libapache2-mod-php${PHP_VERSION} \
                       curl ufw certbot python3-certbot-apache python3-certbot-dns-cloudflare \
                       unzip wget jq
    a2enmod ssl rewrite headers deflate expires
    echo "[INFO] Dependencies successfully installed."
}

# Function: Configure Firewall (UFW)
configure_firewall() {
    echo "[INFO] Configuring UFW firewall..."
    ufw allow 'Apache Full'
    ufw allow OpenSSH
    ufw --force enable
    echo "[INFO] Firewall has been enabled and configured."
}

# Function: Check DNS IP of Domain
check_dns_ip() {
    local DOMAIN="$1"
    echo "[INFO] Checking DNS IP for domain $DOMAIN..."
    local DOMAIN_IP=$(dig +short "$DOMAIN" | tail -n1)
    if [[ "$DOMAIN_IP" == "$SERVER_IP" ]]; then
        echo "[INFO] DNS IP of domain $DOMAIN matches the server IP ($SERVER_IP)."
        return 0
    else
        echo "[WARNING] DNS IP $DOMAIN_IP does not match the server IP ($SERVER_IP)."
        return 1
    fi
}

# Function: Configure SSL Wildcard
configure_ssl_wildcard() {
    local DOMAIN="$1"
    local ADMIN_EMAIL="admin@$DOMAIN"  # Use default EMAIL variable
    echo "[INFO] Enabling SSL wildcard for $DOMAIN..."
    if [ "$CLOUDFLARE_ENABLED" = true ]; then
        echo "dns_cloudflare_api_token = $API_TOKEN" > /etc/letsencrypt/cloudflare.ini
        chmod 600 /etc/letsencrypt/cloudflare.ini
        certbot certonly --dns-cloudflare --dns-cloudflare-credentials /etc/letsencrypt/cloudflare.ini \
                         -d "$DOMAIN" -d "*.$DOMAIN" --non-interactive --agree-tos --email "$ADMIN_EMAIL"
    else
        certbot certonly --manual --preferred-challenges=dns --manual-auth-hook "$AUTH_HOOK" \
                         -d "$DOMAIN" -d "*.$DOMAIN" --agree-tos --manual-public-ip-logging-ok --email "$ADMIN_EMAIL"
    fi
    if [ $? -eq 0 ]; then
        echo "[INFO] SSL wildcard has been successfully enabled for $DOMAIN."
        return 0
    else
        echo "[ERROR] Failed to create SSL wildcard for $DOMAIN."
        return 1
    fi
}

# Function: Configure Apache Virtual Host
configure_virtual_host() {
    local DOMAIN="$1"
    echo "[INFO] Configuring Virtual Host for $DOMAIN..."
    mkdir -p "${ROOT_FOLDER}/${DOMAIN}/public_html"
    cat <<EOF >/etc/apache2/sites-available/${DOMAIN}.conf
<VirtualHost *:80>
    ServerName $DOMAIN
    ServerAlias *.$DOMAIN
    DocumentRoot ${ROOT_FOLDER}/${DOMAIN}/public_html
    RewriteEngine On
    RewriteCond %{HTTPS} off
    RewriteRule ^(.*)\$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}_error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}_access.log combined
</VirtualHost>
<IfModule mod_ssl.c>
<VirtualHost *:443>
    ServerName $DOMAIN
    ServerAlias *.$DOMAIN
    DocumentRoot ${ROOT_FOLDER}/${DOMAIN}/public_html
    <Directory ${ROOT_FOLDER}/${DOMAIN}/public_html>
        Options Indexes FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>
    Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
    AddOutputFilterByType DEFLATE text/plain text/html text/xml text/css
    AddOutputFilterByType DEFLATE application/xml application/xhtml+xml application/rss+xml application/javascript application/x-javascript
    AddOutputFilterByType DEFLATE image/svg+xml
    ExpiresActive On
    ExpiresByType image/jpg "access plus 1 year"
    ExpiresByType image/jpeg "access plus 1 year"
    ExpiresByType image/png "access plus 1 year"
    ExpiresByType image/gif "access plus 1 year"
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/pdf "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
    ExpiresByType text/javascript "access plus 1 month"
    ExpiresByType text/html "access plus 1 month"
    SSLEngine on
    SSLCertificateFile /etc/letsencrypt/live/$DOMAIN/fullchain.pem
    SSLCertificateKeyFile /etc/letsencrypt/live/$DOMAIN/privkey.pem
    ErrorLog \${APACHE_LOG_DIR}/${DOMAIN}_ssl_error.log
    CustomLog \${APACHE_LOG_DIR}/${DOMAIN}_ssl_access.log combined
</VirtualHost>
</IfModule>
EOF
    a2ensite "${DOMAIN}.conf"
    systemctl reload apache2
    echo "[INFO] Virtual Host $DOMAIN has been activated."
}

# Function: Add New Domain
add_domain() {
    local DOMAIN="$1"
    echo "[INFO] Processing domain: $DOMAIN"
    if [[ -z "$DOMAIN" ]]; then
        echo "[ERROR] Domain name cannot be empty."
        return 1
    fi
    if ! check_dns_ip "$DOMAIN"; then
        echo "[WARNING] DNS for domain $DOMAIN does not match the server IP. Process halted."
        return 1
    fi
    if configure_ssl_wildcard "$DOMAIN"; then
        configure_virtual_host "$DOMAIN"
        echo "[INFO] Domain $DOMAIN has been successfully configured."
    else
        echo "[ERROR] Failed to create wildcard SSL for $DOMAIN."
        return 1
    fi
}

# Function: SSL Renewal Cron Job
configure_ssl_renewal() {
    echo "[INFO] Adding SSL renewal cron job..."
    cat <<EOF >"$CRON_FILE"
0 3 * * * root certbot renew --quiet --deploy-hook "systemctl reload apache2"
EOF
    chmod 644 "$CRON_FILE"
    systemctl restart cron
    echo "[INFO] SSL renewal cron job has been set (runs at 3:00 AM)."
}

# Main Function
main() {
    display_banner
    echo "=== Smart Script: Domain Alias and SSL Wildcard ==="
    check_ubuntu_version
    install_dependencies
    configure_firewall
    if [[ ! -f "$DOMAINS_FILE" ]]; then
        echo "[ERROR] $DOMAINS_FILE not found!"
        exit 1
    fi
    mapfile -t DOMAINS < "$DOMAINS_FILE"
    if [[ ${#DOMAINS[@]} -eq 0 ]]; then
        echo "[ERROR] No domains found in $DOMAINS_FILE."
        exit 1
    fi
    for DOMAIN in "${DOMAINS[@]}"; do
        add_domain "$DOMAIN"
        echo
    done
    configure_ssl_renewal
    systemctl enable apache2
    systemctl restart apache2
    echo "[INFO] All domain processes completed."
    if command -v figlet &>/dev/null; then
        figlet -c -f slant "DANA CANVA"
    else
        echo "DANA CANVA"
    fi
    echo
}

main
