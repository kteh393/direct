import os

def debug(message):
    print(f"[DEBUG]: {message}")

# Path input dan output
input_path = "output/dns.txt"
output_path = "output/domains.txt"

debug(f"Input path: {input_path}")
debug(f"Output path: {output_path}")

# Membaca file dari input_path
if os.path.exists(input_path):
    debug(f"File {input_path} ditemukan. Membaca file...")
    with open(input_path, "r") as file:
        format1 = file.read()

    debug("File berhasil dibaca. Memproses data...")
    # Memproses data untuk mengubah ke format 2
    lines = format1.split("\n")
    format2 = "".join([line.split()[0] + "\n" for line in lines if line.strip()])

    debug("Data berhasil diproses. Menyimpan hasil...")
    # Menyimpan hasil ke output_path
    with open(output_path, "w") as file:
        file.write(format2)

    debug(f"Hasil telah disimpan di {output_path}")
    print(f"Hasil telah disimpan di {output_path}")
else:
    debug(f"File {input_path} tidak ditemukan.")
    print(f"File {input_path} tidak ditemukan.")
