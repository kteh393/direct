#!/bin/bash

# Stop SSH services to avoid conflicts
sudo systemctl stop ssh
sudo systemctl stop sshd

# Kill any process using port 22
sudo kill -9 $(sudo lsof -t -i:22) 2>/dev/null

# Update SSH configuration
cat <<EOF | sudo tee /etc/ssh/sshd_config
# /etc/ssh/sshd_config - OpenSSH server configuration

# Port SSH (Default: 2222 to avoid conflicts)
Port 2222

# Listen on all available network interfaces
AddressFamily any
ListenAddress 0.0.0.0
ListenAddress ::

# Authentication settings
PermitRootLogin yes
PasswordAuthentication yes
PubkeyAuthentication no
ChallengeResponseAuthentication no
UsePAM yes

# Logging
SyslogFacility AUTH
LogLevel INFO

# Security settings
PermitEmptyPasswords no
MaxAuthTries 6
MaxSessions 10

# Connection keep-alive settings
TCPKeepAlive yes
ClientAliveInterval 60
ClientAliveCountMax 3

# Allow X11 forwarding (optional, disable if not needed)
X11Forwarding yes

# Disable host-based authentication
HostbasedAuthentication no
IgnoreUserKnownHosts no
IgnoreRhosts yes

# Subsystem for SFTP
Subsystem sftp /usr/lib/openssh/sftp-server

# Allow client to pass locale environment variables
AcceptEnv LANG LC_*
EOF

# Allow new SSH port in firewall
sudo ufw allow 2222/tcp

# Restart SSH service
sudo systemctl start ssh

# Verify SSH service is running
sudo systemctl status ssh