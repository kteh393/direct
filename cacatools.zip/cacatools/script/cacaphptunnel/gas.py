import os
import tarfile
from datetime import datetime
import random
import pyfiglet
from colorama import Fore, Style, init
import shutil
import subprocess

# Inisialisasi colorama
init(autoreset=True)

def print_banner():
    # Menampilkan banner menggunakan pyfiglet
    print(pyfiglet.figlet_format("PHP TUNNEL", font="standard"))
    print(pyfiglet.figlet_format("CACA-CAYA", font="slant"))
    print("=" * 50)

def create_and_extract_tar(folder_path):
    tar_file_name = "assets_public_thema1_thema2.tar.gz"
    tar_file_path = os.path.join(folder_path, tar_file_name)

    # Membuat arsip tar.gz
    with tarfile.open(tar_file_path, "w:gz") as tar:
        tar.add("script/cacaphptunnel/assets", arcname="assets")
        tar.add("script/cacaphptunnel/thema", arcname="thema")
        tar.add("script/cacaphptunnel/brand_list.txt", arcname="brand_list.txt")
        tar.add("script/cacaphptunnel/google6a32ddad881fa12a.html", arcname="google6a32ddad881fa12a.html")
        tar.add("script/cacaphptunnel/google6645fc8fdc18d3c6.html", arcname="google6645fc8fdc18d3c6.html")

    print(Fore.GREEN + f"Arsip {tar_file_name} berhasil dibuat.")

    # Ekstrak arsip tar.gz langsung ke folder_path
    with tarfile.open(tar_file_path, "r:gz") as tar:
        tar.extractall(path=folder_path)

    print(Fore.GREEN + f"Arsip {tar_file_name} berhasil diekstrak langsung ke folder {folder_path}.")


def generate_php_script(domain, string_tunnel, title, description, folder_path):
    # Generate PHP script dynamically
    used_themes = set()

    def get_random_theme():
        nonlocal used_themes
        while True:
            theme = random.randint(1, 12)
            if theme not in used_themes:
                used_themes.add(theme)
                return theme

    def get_random_desc():
        # Daftar frase yang bisa dipilih secara acak
        phrases = [
            "Menawarkan link situs aman", "Pilihan terbaik untuk login", "Pendaftaran mudah tanpa hambatan", "Situs resmi dengan akses cepat", "Platform terpercaya untuk pengguna", "Link resmi login situs terpercaya", "Pendaftaran game online terpercaya", "Login cepat di situs kami", "Platform permainan terpercaya dengan keamanan", "Penyedia link login terpercaya dan cepat", "Situs game dengan akses mudah", "Login dan daftar tanpa biaya", "Platform terkemuka untuk semua permainan", "Menawarkan akses situs link resmi", "Login di situs tanpa gangguan", "Daftar sekarang untuk pengalaman game", "Platform terpercaya untuk pendaftaran mudah", "Situs link terpercaya untuk game", "Daftar game dengan layanan cepat", "Link aman untuk login game", "Login langsung ke situs game", "Platform resmi dengan pendaftaran mudah", "Menawarkan link situs aman dan terpercaya", "Link login yang cepat dan efisien", "Platform dengan fitur login lengkap", "Situs game terpercaya dengan link aman", "Platform terbaik untuk daftar game", "Login tanpa ribet di platform kami", "Daftar game online tanpa biaya tersembunyi", "Platform terbaik dengan akses cepat", "Link login untuk permainan gacor", "Menawarkan link situs game terbaik", "Login di situs tanpa kerumitan", "Pendaftaran situs game secara langsung", "Situs game terpercaya dengan link aman", "Platform game dengan login cepat", "Daftar sekarang untuk pengalaman terbaik", "Penyedia situs game dengan akses aman", "Link login terpercaya dan cepat", "Platform game dengan pengalaman pengguna", "Situs terpercaya dengan fitur lengkap", "Pendaftaran di situs gaming resmi", "Link login tanpa kendala pada platform", "Platform terpercaya untuk semua jenis game", "Daftar tanpa biaya pendaftaran tersembunyi", "Menawarkan situs link dengan akses langsung", "Login mudah di situs resmi kami", "Situs game online dengan link aman", "Platform terbaik untuk penggemar game", "Daftar di situs dengan sistem aman", "Link login untuk platform terpercaya", "Pendaftaran di situs game online", "Situs terpercaya dengan fitur lengkap", "Login aman di situs terpercaya", "Platform resmi untuk login dan daftar", "Situs terbaik untuk pengalaman game", "Penyedia situs link untuk permainan", "Login game cepat tanpa hambatan", "Platform dengan sistem login teraman", "Situs link terpercaya untuk daftar online", "Daftar game secara langsung dan aman", "Login cepat tanpa masalah pada platform", "Situs game terpercaya dengan link instan", "Menawarkan platform dengan pendaftaran mudah", "Link situs yang mudah diakses", "Platform resmi dengan link yang aman", "Login tanpa masalah di platform terpercaya", "Pendaftaran game mudah tanpa biaya tambahan", "Situs link terpercaya dengan fitur aman", "Platform dengan login dan akses cepat", "Pendaftaran tanpa hambatan di situs kami", "Link login untuk platform game terbaik", "Situs permainan online dengan akses mudah", "Menawarkan platform permainan terpercaya dan aman", "Pendaftaran gratis di situs game", "Link situs untuk login game terpercaya", "Platform terbaik untuk pengalaman permainan", "Situs game dengan link aman dan cepat", "Login langsung di platform permainan", "Daftar di platform dengan keamanan terjamin", "Link resmi situs dengan akses mudah", "Penyedia login game terpercaya dan cepat", "Situs terpercaya untuk permainan gacor", "Daftar game tanpa biaya tersembunyi", "Link login untuk permainan tanpa gangguan", "Penyedia platform game dengan fitur lengkap", "Situs terpercaya dengan layanan login cepat", "Platform resmi dengan pendaftaran mudah", "Login aman dan cepat di situs kami", "Situs dengan link login yang aman", "Daftar sekarang dan nikmati bonus", "Link situs resmi untuk pendaftaran gratis", "Penyedia game terpercaya dengan login cepat", "Platform dengan login tanpa kendala", "Situs game dengan link login resmi", "Pendaftaran game terpercaya di situs kami", "Link situs untuk login tanpa masalah", "Daftar dan mainkan game di platform", "Situs terpercaya untuk login dan daftar", "Platform dengan login aman dan mudah", "Situs game dengan pendaftaran gratis", "Link login untuk game online terpercaya", "Platform game online dengan akses mudah", "Situs terpercaya dengan pendaftaran langsung", "Penyedia situs untuk login dan mainkan", "Situs resmi untuk login permainan", "Pendaftaran game online tanpa hambatan", "Link resmi untuk login situs game", "Platform terpercaya dengan sistem login mudah", "Daftar dan mainkan game online dengan mudah", "Link login yang mudah dan cepat", "Situs terpercaya untuk login dengan aman", "Platform game terbaik untuk pengalaman online", "Situs permainan online dengan login mudah", "Daftar game langsung di situs terpercaya", "Login tanpa hambatan di platform gaming", "Link login dengan keamanan tinggi dan cepat", "Situs terpercaya untuk permainan online terbaru", "Platform terpercaya dengan akses game cepat", "Penyedia link situs untuk pendaftaran online", "Situs dengan login cepat dan aman", "Pendaftaran di platform gaming terpercaya", "Login mudah dan langsung di situs kami", "Daftar di situs game resmi dan terpercaya", "Platform game terpercaya untuk akses tanpa gangguan", "Situs terpercaya dengan pendaftaran dan login aman", "Link login terpercaya untuk game online", "Pendaftaran cepat di situs game kami", "Situs permainan terpercaya dengan akses instan", "Login mudah dan cepat tanpa gangguan", "Daftar game online tanpa biaya tersembunyi", "Situs resmi untuk login dan mendaftar", "Penyedia situs terpercaya dengan pendaftaran gratis", "Platform dengan akses game cepat dan mudah", "Daftar sekarang untuk akses eksklusif", "Link situs game terpercaya dan aman", "Login game dengan layanan terbaik", "Penyedia login cepat dan terpercaya", "Platform terpercaya dengan game lengkap", "Daftar tanpa masalah di situs kami", "Situs dengan link login tanpa hambatan", "Pendaftaran game langsung tanpa biaya tersembunyi", "Platform terpercaya dengan pendaftaran tanpa masalah", "Login cepat dan aman di platform kami", "Situs permainan online dengan akses mudah", "Penyedia situs game dengan link aman", "Daftar untuk bermain game langsung di platform", "Situs resmi dengan sistem login aman", "Platform game dengan pendaftaran yang mudah", "Situs terpercaya dengan sistem login terjamin", "Link login terpercaya untuk setiap permainan", "Penyedia platform game dengan fitur lengkap", "Situs terpercaya untuk login tanpa masalah", "Daftar game di platform kami sekarang", "Link login aman dan cepat di situs", "Platform terbaik untuk pengalaman bermain", "Situs terpercaya dengan akses cepat", "Daftar game tanpa biaya di platform", "Login tanpa masalah di situs terpercaya", "Penyedia platform permainan dengan link cepat", "Platform gaming dengan sistem login aman", "Situs game dengan akses tanpa hambatan", "Pendaftaran game langsung di platform terpercaya", "Link login untuk situs permainan terbaik", "Platform game terbaik untuk pendaftaran mudah", "Situs terpercaya dengan fitur login cepat", "Login game tanpa hambatan di platform", "Penyedia game terpercaya dengan link cepat", "Situs resmi untuk mendaftar dan bermain", "Login instan ke situs permainan", "Daftar game online tanpa ribet", "Link login dengan sistem keamanan canggih", "Situs terpercaya dengan pendaftaran cepat", "Penyedia platform game terpercaya dan cepat", "Situs permainan online terpercaya dengan link aman", "Platform dengan sistem login terpercaya", "Daftar untuk bermain game dengan mudah", "Situs terpercaya untuk login tanpa kesulitan", "Link login untuk situs game terpercaya", "Platform game dengan akses login cepat", "Situs permainan terpercaya dengan pendaftaran mudah", "Penyedia situs terpercaya dengan layanan login", "Daftar sekarang dan nikmati akses cepat", "Login ke situs tanpa gangguan", "Situs permainan dengan fitur login cepat", "Pendaftaran game langsung tanpa hambatan", "Platform terpercaya dengan sistem login aman", "Situs terpercaya untuk permainan online cepat", "Login mudah dan cepat di situs resmi", "Daftar untuk akses ke game terbaru", "Penyedia platform game dengan akses mudah", "Situs dengan login terpercaya untuk game", "Daftar untuk bermain di platform kami", "Link login aman untuk permainan gacor", "Platform terpercaya dengan pendaftaran langsung", "Situs resmi untuk pendaftaran dan login", "Penyedia situs terpercaya dengan fitur lengkap", "Login cepat di platform game terpercaya", "Situs permainan dengan login dan pendaftaran", "Daftar di platform game terbaik sekarang",
            # Add more phrases here...
        ]
        # Mengambil frase acak dari daftar
        return random.choice(phrases)
    
    def get_random_title():
        # Daftar frase yang bisa dipilih secara acak
        phrasess = [
            "$brand # Link Alternatif", "$brand # Link Situs", "$brand # Link Situs Alternatif", "$brand # Login Alternatif", "$brand # Login Situs", "$brand # Platform Situs", "$brand # Platform Situs Judi Slot Online", "$brand # Situs Link", "$brand # Situs Slot Online Terpercaya 2025", "$brand $ Link Alternatif", "$brand $ Link Situs", "$brand $ Link Situs Alternatif", "$brand $ Link Situs Slot Gacor Hari Ini", "$brand $ Login Alternatif", "$brand $ Login Situs", "$brand $ Situs Link", "$brand - Link Alternatif", "$brand - Link Situs", "$brand - Link Situs Alternatif", "$brand - Login Alternatif", "$brand - Login Situs", "$brand - Situs Link", "$brand - Website", "$brand : Link Alternatif", "$brand : Link Situs", "$brand : Link Situs Alternatif", "$brand : Login Alternatif", "$brand : Login Situs", "$brand : Situs Judi Slot Gacor Hari ini Gampang Maxwin 2025", "$brand : Situs Link", "$brand Layanan Informasi", "$brand Link Daftar Situs Slot Server Thailand ", "$brand Link Situs", "$brand Link Slot Gacor Hari Ini Gampang Menang Maxwin", "$brand LOGIN | LINK ALTERNATIF ", "$brand Resmi: Link Situs Slot Gacor 777", "$brand RTP Daftar Link Slot Deposit Pulsa", "$brand | Link Alternatif", "$brand | Link Situs", "$brand | Link Situs Alternatif", "$brand | Login Alternatif", "$brand | Login Situs", "$brand | Situs Link", "$brand » Link Alternatif", "$brand » Link Situs", "$brand » Link Situs Alternatif", "$brand » Link Situs Slot Gacor Qris", "$brand » Login Alternatif", "$brand » Login Situs", "$brand » Situs Link", "$brand ⚡️  Link Alternatif", "$brand ⚡️  Link Situs", "$brand ⚡️  Link Situs Alternatif", "$brand ⚡️  Login Alternatif", "$brand ⚡️  Login Situs", "$brand ⚡️  Situs Link", "$brand ⚡️ Situs Slot Server Thailand Sensasional ", "$brand 𒎓 Link Alternatif", "$brand 𒎓 Link Situs", "$brand 𒎓 Link Situs Alternatif", "$brand 𒎓 Login Alternatif", "$brand 𒎓 Login Situs", "$brand 𒎓 Situs $brand depo 5K", "$brand 𒎓 Situs Link", "$brand 🍀 Link Alternatif", "$brand 🍀 Link Situs", "$brand 🍀 Link Situs Alternatif", "$brand 🍀 Link Situs Slot Gacor 2025 ", "$brand 🍀 Link Situs Slot Gacor 2025 Online Maxwin ", "$brand 🍀 Login Alternatif", "$brand 🍀 Login Situs", "$brand 🍀 Situs Link", "$brand 🏆 Gerbang Luar Biasa Megah Slot Beruntung", "$brand 🏆 Link Alternatif", "$brand 🏆 Link Situs", "$brand 🏆 Link Situs Alternatif", "$brand 🏆 Login Alternatif", "$brand 🏆 Login Situs", "$brand 🏆 Situs Link", "$brand 🐣 Link Alternatif", "$brand 🐣 Link Situs", "$brand 🐣 Link Situs Alternatif", "$brand 🐣 Login Alternatif", "$brand 🐣 Login Situs", "$brand 🐣 Situs Link", "$brand 🐣 Situs Slot Thailand Gacor Terpercaya ", "$brand: Link Situs ", "$brand: Link Situs Judi Slot Gacor Hari Ini Slot88", "$brand: Link Situs Judi Slot Gacor Terbaru Hari Ini ", "$brand: Link Situs Judi Slot Online Gacor Hari Ini ", "$brand: Link Situs Slot Gacor Hari Ini ", "$brand: Link Situs Slot Gacor Maxwin Server Thailand", "$brand: Situs Slot Gacor Hari Ini Gampang Menang Maxwin ", "$brand: Situs Slot Gacor Qris Hari Ini Gampang Menang .", "$brand: Slot88 Situs Slot Online Gacor Hari Ini &", "Slot Thailand ! Link Server Thailand Gacor Terbaik", "Website $brand Pusat layanan",
            # Add more phrases here...
        ]
        # Replace $brand with actual domain or string
        return random.choice(phrasess)

    random_theme = get_random_theme()
    random_title = get_random_title()  # Mengambil frase acak
    random_desc = get_random_desc()

    # Assuming the template for PHP script needs title and description
    php_script = f"""
<?php
$domain = \"{domain}\";
$namaweb = str_replace('.', '-', $domain);
$icon = \"/assets/img/favicon.png\";
$logo = \"/assets/img/logo.png\";
$banner = \"/assets/img/banner.webp\";

$valid_brands = file(\"brand_list.txt\", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (!$valid_brands) {{
    header(\"HTTP/1.1 404 Not Found\");
    echo \"<h1>404 - Halaman Tidak Ditemukan</h1>\";
    exit();
}}

function is_valid_brand($input, $valid_brands) {{
    $normalized_input = preg_replace('/[^a-zA-Z0-9]/', '', $input);
    foreach ($valid_brands as $brand) {{
        $normalized_brand = preg_replace('/[^a-zA-Z0-9]/', '', $brand);
        if (strcasecmp($normalized_input, $normalized_brand) === 0) {{
            return true;
        }}
    }}
    return false;
}}

if (isset($_GET['{string_tunnel}'])) {{
    $id = $_GET['{string_tunnel}'];
    if (!is_valid_brand($id, $valid_brands)) {{
        header(\"HTTP/1.1 404 Not Found\");
        echo \"<h1>404 - Halaman Tidak Ditemukan</h1>\";
        exit();
    }}
    $brand = strtoupper(str_replace('-', ' ', $id));
    $url = \"https://$domain\";
    $amp = \"https://banpolsemogaberuntung.pages.dev/?amp-$namaweb=\" . urlencode($id);
    $canonical = \"https://{domain}/?{string_tunnel}=\" . urlencode($id);

    $title = \"{random_title} {title}\";
    $description = \"{random_desc} {description}\";
    include(\"thema/\" . {random_theme} . \".php\");
    exit();
}}

if (isset($_SERVER['HTTP_HOST'])) {{
    $host = $_SERVER['HTTP_HOST'];
    if (stripos($host, $domain) !== false) {{
        $subdomain = str_replace(\".$domain\", \"\", $host);
        if (!is_valid_brand($subdomain, $valid_brands)) {{
            header(\"HTTP/1.1 404 Not Found\");
            echo \"<h1>404 - Halaman Tidak Ditemukan</h1>\";
            exit();
        }}
        $brand = strtoupper(str_replace('-', ' ', $subdomain));
        $amp = \"https://banpolsemogaberuntung.pages.dev/?amp-$namaweb=\" . urlencode($subdomain);
        $canonical = \"https://$subdomain.$domain/\";

    $title = \"{random_title} {title}\";
    $description = \"{random_desc} {description}\";
        include(\"thema/\" . {random_theme} . \".php\");
        exit();
    }}
}}

header(\"HTTP/1.1 404 Not Found\");
echo \"<h1>404 - Halaman Tidak Ditemukan</h1>\";
exit();
?>
"""
    index_file_path = os.path.join(folder_path, 'index.php')
    with open(index_file_path, 'w') as f:
        f.write(php_script)

    print(f"Skrip PHP berhasil dibuat di {index_file_path}.")

def generate_sitemap(subdomains, file_name, base_url, url_type, string_tunnel):
    sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n'
    sitemap += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'

    for subdomain in subdomains:
        if url_type == "brand":
            url = f"https://{base_url}/?{string_tunnel}={subdomain.replace('%2B', '+')}"
        elif url_type == "subdomain":
            formatted_subdomain = subdomain.replace('+', '-')
            url = f"https://{formatted_subdomain}.{base_url}/"
        sitemap += f'  <url>\n'
        sitemap += f'    <loc>{url}</loc>\n'
        sitemap += f'  </url>\n'

    sitemap += '</urlset>\n'

    with open(file_name, 'w') as f:
        f.write(sitemap)

def generate_sitemap_index(total_sitemaps, base_url, file_name, sitemap_type):
    index = '<?xml version="1.0" encoding="UTF-8"?>\n'
    index += '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'

    for i in range(1, total_sitemaps + 1):
        if sitemap_type == "subdomain":
            sitemap_url = f"https://{base_url}/subsitemap-{i}.xml"
        elif sitemap_type == "brand":
            sitemap_url = f"https://{base_url}/brandsitemap-{i}.xml"
        lastmod = datetime.now().strftime('%Y-%m-%d')
        index += f'  <sitemap>\n'
        index += f'    <loc>{sitemap_url}</loc>\n'
        index += f'    <lastmod>{lastmod}</lastmod>\n'
        index += f'  </sitemap>\n'

    index += '</sitemapindex>\n'

    with open(file_name, 'w') as f:
        f.write(index)

def generate_robots_txt(base_url, folder_path):
    robots_txt = f"User-agent: *\n"
    robots_txt += "Disallow:\n\n"
    robots_txt += f"Sitemap: https://{base_url}/subsitemap-index.xml\n"
    robots_txt += f"Sitemap: https://{base_url}/brandsitemap-index.xml\n"

    file_path = os.path.join(folder_path, "robots.txt")
    with open(file_path, 'w') as f:
        f.write(robots_txt)

def check_and_setup_user(user, group):
    try:
        # Check if user exists
        subprocess.run(["id", "-u", user], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        print(Fore.YELLOW + f"User '{user}' tidak ditemukan. Membuat user baru...")
        subprocess.run(["sudo", "useradd", "-r", "-d", "/var/www", "-s", "/usr/sbin/nologin", "-g", group, user], check=True)
        print(Fore.GREEN + f"User '{user}' berhasil dibuat.")

def set_permissions_and_ownership(folder_path, user, group):
    print(Fore.YELLOW + "Mengatur permission dan ownership untuk meningkatkan SEO...")

    # Set ownership untuk user dan group yang diberikan
    for root, dirs, files in os.walk(folder_path):
        for dir in dirs:
            shutil.chown(os.path.join(root, dir), user=user, group=group)
        for file in files:
            shutil.chown(os.path.join(root, file), user=user, group=group)

    # Set permission untuk semua folder menjadi 755
    for root, dirs, files in os.walk(folder_path):
        for dir in dirs:
            os.chmod(os.path.join(root, dir), 0o755)

    # Set permission untuk semua file menjadi 644
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            os.chmod(os.path.join(root, file), 0o644)

    # Pastikan file robots.txt memiliki permission 644
    robots_txt_path = os.path.join(folder_path, "robots.txt")
    if os.path.exists(robots_txt_path):
        os.chmod(robots_txt_path, 0o644)

    print(Fore.GREEN + "Permission dan ownership berhasil disesuaikan untuk mendukung SEO!")

# Missing function implementations (examples given above)

def read_file(file_path):
    """Helper function to read a file and return a list of stripped lines."""
    try:
        with open(file_path, 'r') as f:
            return [line.strip() for line in f if line.strip()]
    except FileNotFoundError:
        print(f"Error: File '{file_path}' tidak ditemukan.")
        return []


def main():
    # Read input files
    domains = read_file('script/cacaphptunnel/domain.txt')
    titles = read_file('script/cacaphptunnel/title.txt')
    descriptions = read_file('script/cacaphptunnel/description.txt')
    folder_paths = read_file('script/cacaphptunnel/folder_path.txt')
    string_tunnels = read_file('script/cacaphptunnel/string_tunnel.txt')

    # Read subdomains from brand_list.txt
    subdomains = read_file('script/cacaphptunnel/brand_list.txt')

    # Ensure folders exist
    for folder_path in folder_paths:
        os.makedirs(folder_path, exist_ok=True)

    # Set up the user and group
    user = "www-data"
    group = "www-data"
    check_and_setup_user(user, group)

    # Loop through the lists of domains, titles, descriptions, and string tunnels
    for i in range(len(domains)):
        domain = domains[i]
        title = titles[i] if i < len(titles) else "Default Title"
        description = descriptions[i] if i < len(descriptions) else "Default Description"
        string_tunnel = string_tunnels[i] if i < len(string_tunnels) else "default"
        folder_path = folder_paths[i % len(folder_paths)]  # Cycle through folder paths if necessary

        print(f"\nProcessing domain: {domain}")
        print(f"Title: {title}")
        print(f"Description: {description}")
        print(f"String Tunnel: {string_tunnel}")
        print(f"Folder Path: {folder_path}")
        
        # Generate PHP script and extract tar
        generate_php_script(domain, string_tunnel, title, description, folder_path)
        create_and_extract_tar(folder_path)

        # Create sitemaps
        max_urls_per_sitemap = 20000
        total_sitemaps = (len(subdomains) + max_urls_per_sitemap - 1) // max_urls_per_sitemap

        for i in range(1, total_sitemaps + 1):
            subset = subdomains[(i - 1) * max_urls_per_sitemap : i * max_urls_per_sitemap]
            generate_sitemap(
                subset, 
                os.path.join(folder_path, f"brandsitemap-{i}.xml"), 
                domain, 
                "brand",
                string_tunnel
            )
            generate_sitemap(
                subset, 
                os.path.join(folder_path, f"subsitemap-{i}.xml"), 
                domain, 
                "subdomain",
                string_tunnel
            )

        # Generate sitemap index
        generate_sitemap_index(
            total_sitemaps, 
            domain, 
            os.path.join(folder_path, "subsitemap-index.xml"), 
            "subdomain"
        )
        generate_sitemap_index(
            total_sitemaps, 
            domain, 
            os.path.join(folder_path, "brandsitemap-index.xml"), 
            "brand"
        )

        # Generate robots.txt
        generate_robots_txt(domain, folder_path)

        # Set permissions and ownership
        set_permissions_and_ownership(folder_path, user, group)

    print(Fore.GREEN + "Semua langkah selesai! Website siap digunakan.")

if __name__ == "__main__":
    main()